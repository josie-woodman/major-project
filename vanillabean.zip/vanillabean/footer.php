<?php
/**
 * THE FOOTER TEMPLATE
 
 */

?>

<footer class="footer">
<img src="wp-content/uploads/2021/01/vanillabean-logo.png" alt="vanillabean-logo">	
<p>&copy VanillaBean Ice Cream | Proudly Designed by <a class="woodman-studios" href="https://www.woodmanstudios.com">Woodman Studios</a></p>
</footer>


<?php 
	wp_footer();
?>
</body>
</html>